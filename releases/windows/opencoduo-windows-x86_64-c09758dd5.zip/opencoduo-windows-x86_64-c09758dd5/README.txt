Open CoD:UO multiplayer Windows x86_64 build

Copy the contents of this directory into the root of an existing
Call of Duty: United Offensive installation. Preserve the uo/ directory.
This package is not standalone and contains no retail game data.

This x86-64 build uses the built-in Miniaudio backend.

Packaged components:
  CoDUOMP.exe                     Open CoD:UO multiplayer client
  uo/uo_cgame_mp_x86.dll          Open CoD:UO client-game module
  uo/uo_ui_mp_x86.dll             Open CoD:UO user-interface module
  uo/uo_game_mp_x86.dll           Open CoD:UO listen-server game module
